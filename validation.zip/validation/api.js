const express = require('express');
const mongoose = require('./db'); 
const bcrypt = require('bcryptjs');
const app = express();
const port = 3000;

app.use(express.json());

// Define a Mongoose schema for the User
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, 
}
});

const User = mongoose.model('User', userSchema);


app.post("/signin", async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find user in the database
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ "msg": "Invalid username or password" });
        }

        // Compare the entered password with the hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(404).json({ "msg": "Invalid username or password" });
        }

        return res.status(200).json({ "msg": "Signin successful" });
    } catch (error) {
        return res.status(500).json({ "msg": "Server error", "error": error.message });
    }
});


app.post("/signup", async (req, res) => {
    const { username, email, password } = req.body;

    try {
        // Check if user already exists with the email or username
        const existingUserEmail = await User.findOne({ email });
        if (existingUserEmail) {
            return res.status(400).json({ "msg": "User email already exists" });
        }

        const existingUserUsername = await User.findOne({ username });
        if (existingUserUsername) {
            return res.status(400).json({ "msg": "Username already exists" });
        }

        // Hash the password before saving it to the database
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create a new user with the hashed password
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        return res.status(201).json({ "msg": "Signup successful" });
    } catch (error) {
        return res.status(500).json({ "msg": "Server error", "error": error.message });
    }
});


app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
